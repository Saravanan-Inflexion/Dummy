sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("ui5freestyleapp.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);